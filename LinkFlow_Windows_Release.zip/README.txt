﻿LinkFlow - Windows Release Package
==================================
1. Extract ALL files from this ZIP into a folder (do not run directly inside the ZIP).
2. (Optional, for Game Controller) Run ViGEmBusSetup.exe once to install the virtual Xbox 360 driver.
3. Double-click LinkFlow.exe to start!
4. Install LinkFlow.apk on your Android phone and connect via Wi-Fi, Hotspot, or USB.
